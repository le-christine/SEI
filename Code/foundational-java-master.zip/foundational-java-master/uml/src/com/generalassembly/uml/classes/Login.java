package com.generalassembly.uml.classes;

public class Login {
    public void login() {
    }
}
