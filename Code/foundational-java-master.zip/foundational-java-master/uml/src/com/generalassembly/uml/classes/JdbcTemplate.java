package com.generalassembly.uml.classes;

public class JdbcTemplate {
}
