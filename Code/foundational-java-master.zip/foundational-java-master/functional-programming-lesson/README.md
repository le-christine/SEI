# ![](https://ga-dash.s3.amazonaws.com/production/assets/logo-9f88ae6c9c3871690e33280fcf557f33.png) Functional Programming

## Table of Contents

| Order | Topic | Type | Timing |
| --- | ------ | --- | --- |
| 1 | Lambda Expressions | Lesson | 1:30 |
| 2 | Stream processing and Collectors | Lesson | 1:30 |
| 3 | Functional Interfaces | Lesson | 1:30 |
| 4 | Optionals | Lesson | 1:30 |
