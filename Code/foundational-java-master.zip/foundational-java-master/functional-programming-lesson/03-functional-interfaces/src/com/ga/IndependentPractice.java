package com.ga;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class IndependentPractice {

    public static void main(String[] args) {

        List<Integer> list1 = Arrays.asList(1,3,4,5,6);
        List<Integer> list2 = Arrays.asList(1,3,4,5,6);

        //Write a BiFunction that compares to see if list1 and list2 are equal.

        //Rewrite the previous example to leverage a method reference on the Integer class

        List<Integer> numberList = Arrays.asList(4,9,16,25,36,49,64,81);

        //Write a Function that will return the square of a given number.  Then iterate
        //the numberList and print out the results.

    }
}
