package com.ga.superhero;

public class Superhero {

}
