# Java Basics

### Table of Contents

| Order | Topic | Type | Time |
| -- | ----- | --- | -- |
| 1 | Computers and Java | Lesson | 0:30 |
| 2 | My First Java | Lesson | 1:00 |
| 3 | Data Types and Variables | Lesson | 1:30 |
| 4 | Control Flow and Loops | Lesson | 1:30 |
| 5 | Functions and Scope | Lesson | 1:30 |
| 6 | Functions | Lab or HW | 1:30 |
| 7 | Arrays and ArrayLists | Lesson | 1:30 |
| 8 | LinkedLists and Maps | Lesson | 1:30 |
| 9 | Debugging and Exception Handling | Lesson | 2:00 |
| 10 | Java Project: Rock, Paper, Scissors | Project | 6:00 |
| 11 | jUnit Testing | Lesson | 1:15 |
| 12 | jUnit Testing | Lab | 1:30 |

This directory also contains older versions of Java basics lessons.

