package com.generalassembly.datatypes;

import java.util.Date;

public class DateHandling {
    public static void main(String[] args) {
        Date date = new Date();
    }
}
