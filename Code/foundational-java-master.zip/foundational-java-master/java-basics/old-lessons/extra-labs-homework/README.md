This directory contains extra materials that can be used as labs, homework, morning exercise, etc. throughout the course. 

Most of the activities are related to Java programming concepts.
