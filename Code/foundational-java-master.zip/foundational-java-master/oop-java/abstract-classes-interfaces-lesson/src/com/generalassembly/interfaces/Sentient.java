package com.generalassembly.oop.interfaces;

public interface Sentient {
    void feel();
}
