package com.generalassembly.abstractlesson;

public abstract class Shape {
        public abstract double getCircumference();

        public abstract double getArea();
}

