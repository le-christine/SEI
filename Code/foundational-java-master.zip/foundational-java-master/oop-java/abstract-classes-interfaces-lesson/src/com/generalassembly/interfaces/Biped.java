package com.generalassembly.oop.interfaces;

public interface Biped {
    void walk();
}
