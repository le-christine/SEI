## OOP Lesson Overview


| Order | Topic | Type | Timing |
| -- | ------ | --- | -- |
| 1 | Introduction to Object-Oriented Programming | Lesson | 0:30 |
| 2 | Objects and Classes | Lesson | 1:30 |
| 3 | Creating Classes | Lab | 1:30 |
| 4 | Subclasses | Lesson | 1:30 |
| 5 | Subclassing | Lab or HW | 1:30 |
| 6 | Abstract Classes and Interfaces | Lesson | 1:30 |
