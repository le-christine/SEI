package AbstractionLab;

public interface IPet {
	void feed();
	void play();
	void groom();
}
