package AbstractionLab;


public class Driver {

	public static void main(String[] args) {
		//Create households and add to list or array
		
		//iterate through list or array and perform required actions
	}

}
