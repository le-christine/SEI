public class Animal {
    private int numLegs;
    private int topSpeed;
    private boolean isEndangered;
    private String name;

    public Animal(int numLegs, int topSpeed, boolean isEndangered, String name){
        //Set properties here
    }

    //Put getters and setters here
}
