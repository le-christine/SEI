// import Animal class

public class Main {

    public static void main(String[] args) {

        //Instantiate new Animal
        Animal animal = ;

        String name;
        int topSpeed;

        //get name and speed values using getters
        name = ;
        topSpeed = ;

        //Print some output
        output.setText();

        //Set new name, speed, and endangered properties values using setters


        //get new values using getters
        name = ;
        topSpeed = ;

        //Print some output
        changedOutput.setText();
    }
}
